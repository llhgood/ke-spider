# 使用说明
1. 确保以下文件在同一目录：
   - ke-spider-macos (可执行文件)
   - cookies.txt (需要替换为真实的cookies)
   - 房源.xlsx (数据文件)
2. 给可执行文件添加运行权限: chmod +x ke-spider-macos
3. 运行: ./ke-spider-macos
